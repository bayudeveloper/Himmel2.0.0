# Himmel API v1.5.6

> Simple, Stable, and Reliable REST API — built with Express.js

---

## 🚀 Deploy / Hosting

### Vercel
```bash
vercel deploy
```

### Railway
1. Push ke GitHub
2. Connect repo di [railway.app](https://railway.app)
3. Railway otomatis baca `railway.toml`
4. Set environment variable: `NODE_ENV=production`

### Render
1. Push ke GitHub  
2. New Web Service di [render.com](https://render.com)
3. Build: `npm install` | Start: `node index.js`
4. Health check: `/health`

### Koyeb
1. Push ke GitHub
2. New App di [koyeb.com](https://koyeb.com)
3. Port: `3000` (atau set `PORT` env)
4. Health path: `/health`

### VPS / Lokal
```bash
npm install
npm start
# Atau dengan port custom:
PORT=8080 npm start
```

---

## 🛡️ Fitur Keamanan & Stabilitas

### Bypass Cloudflare
Semua request ke situs eksternal menggunakan `src/lib/cfBypass.js`:
- Rotasi User-Agent otomatis (pool 8 UA realistis)
- Header browser lengkap (Sec-Ch-Ua, Sec-Fetch-*, dll)
- Retry otomatis dengan exponential backoff
- Deteksi CF block (403/503) dan ganti UA

### Rate Limiter / Overlimit
Perlindungan per-IP berdasarkan kategori endpoint:

| Endpoint | Limit | Window |
|----------|-------|--------|
| `/ai/*` | 10 req | 1 menit |
| `/downloader/*` | 10 req | 1 menit |
| `/tools/*` | 30 req | 1 menit |
| `/random/*` | 30 req | 1 menit |
| `/search/*` | 60 req | 1 menit |
| `/info/*` | 60 req | 1 menit |

Response saat overlimit (HTTP 429):
```json
{
  "status": false,
  "error": "overlimit",
  "message": "Terlalu banyak request!",
  "retry_after": "45 detik",
  "limit": 10,
  "window": "60 detik"
}
```

### Uptime Monitoring
- `GET /health` — Status server, uptime, memory, error count
- `GET /ping` — Pong sederhana untuk keep-alive

---

## 📚 Dokumentasi API

Buka di browser setelah deploy. Semua endpoint terdaftar di halaman utama.

---

## 🔧 Konfigurasi

Edit `src/settings.json` untuk ubah nama creator, link, dan kategori API yang tampil di halaman utama.
